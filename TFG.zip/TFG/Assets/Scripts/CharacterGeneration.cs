﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;
public class CharacterGeneration : MonoBehaviour
{

    //public bool mov;
    //float speed = 4.0f;
    //float gravity = 8.0f;
    //float rot = 0.0f;
    //float rotSpeed = 200.0f;

    //Vector3 moveDir = Vector3.zero;
    //CharacterController controller;
    //Animator anim;

    //Colli enemycolli;
    //ProceduralEnemy enemyproc;


    //GameObject[] effect;
    Renderer rend;
    float timer=0;

    [HideInInspector]
    public bool notallMaterial;
    [HideInInspector]
    public bool proceduralTexture;
    [HideInInspector]
    public bool proceduralColor;
    [HideInInspector]
    public bool proceduralShader;

    public bool exclusiveSkills;

    public int proceduralNumber;

    public Transform[] effectTransform;
    
    //bool exist;

    //GameObject enemy;

   // [System.NonSerialized]
    public bool death;

    GameObject proceduralController;
    Controller newcontrol;


   //List<ClassSkill> SkillsInitial;
    List<ClassSkill> list = new List<ClassSkill>();

    [System.NonSerialized]
    public List<ClassSkill> selected = new List<ClassSkill>();


    List<ClassSkill> aux = new List<ClassSkill>();

    public float difficult;

    
    private ClassSkill Chose(float siz, List<ClassSkill> list)
    {
        ClassSkill chosen = new ClassSkill();
        float random = UnityEngine.Random.Range(0, siz);
        for(int i=0; i<list.Count; i++)
        {
            random = random - list[i].actualValue;
            if (random ==0 || random < 0)
            {
                chosen = list[i];
                i = list.Count;
            }
        }
        return chosen;
    }

    //calcular el tamaño de las listas 
    private float Size(List<ClassSkill> list)
    {
        float valor=0;
        for (int i=0; i<list.Count;i++)
        {
            valor += list[i].actualValue;
        }
        return valor;
    }

    private void Procedural()
    {


        for (int i = 0; i < proceduralNumber; i++)
        {

            ClassSkill first = Chose(newcontrol.LearnedValue, list);
            



                if ((!first.tag.Contains(this.tag) || !first.exclusive.Contains(i)))
                {
                    for (int j = 0; j < list.Count; j++)
                    {

                        if ((list[j].tag.Contains(this.tag) || list[j].tag.Count == 0) && (list[j].exclusive.Contains(i) || list[j].exclusive.Count == 0))
                        {
                            aux.Add(list[j]);

                        }
                    }
                    first = Chose(Size(aux), aux);
                    aux.Clear();

                }
 
            selected.Add(first);

            if (exclusiveSkills == true)
            {
                newcontrol.LearnedValue -= first.actualValue;
                list.Remove(first);
            }



            for (int j = 0; j < list.Count; j++)
            {
                for (int k = 0; k < first.counter.Count; k++)
                {
                    if (list[j].type == first.counter[k])
                    {
                        newcontrol.LearnedValue -= list[j].actualValue;
                        list.Remove(list[j]);

                    }
                }


            }
        }
    }

    private void ProceduralAllMaterial()
    {
        for (int i = 0; i < proceduralNumber; i++)
        {
            rend.materials[i].CopyPropertiesFromMaterial(selected[i].skill.GetComponent<Renderer>().sharedMaterial);
        }
    }

    private void ProceduralColor()
    {
        for (int i = 0; i < proceduralNumber; i++)
        {
            rend.materials[i].color = selected[i].skill.GetComponent<Renderer>().sharedMaterial.color;
        }
    }

    private void ProceduralTexture()
    {
        for (int i = 0; i < proceduralNumber; i++)
        {
            rend.materials[i].mainTexture = selected[i].skill.GetComponent<Renderer>().sharedMaterial.mainTexture;
        }
    }

    private void ProceduralShader()
    {
        for (int i = 0; i < proceduralNumber; i++)
        {
            rend.materials[i].shader = selected[i].skill.GetComponent<Renderer>().sharedMaterial.shader;
        }
    }
    /*
    void addDifficult()
    {

        for (int i = 0; i < selected.Count; i++)
        {
            for (int j = 0; j < Skills.Count; j++)
                if (Skills[j].Equals(selected[i]))
                {
                    Skills[j].time = Time.deltaTime;
                }
        }
        exist = false;

        ClassCombination comb = new ClassCombination(selected, difficult);

        if (newcontrol.skillCombinations.Count != 0)
        {
            for (int k = 0; k < newcontrol.skillCombinations.Count; k++)
            {
                if (newcontrol.skillCombinations[k].combination.Equals(selected))
                {
                    exist = true;
                    newcontrol.skillCombinations[k].time.Add(difficult);
                    newcontrol.skillCombinations[k].veces++;
                }

            }
        }
    }
    */
    /*
    void addTimer()
    {

        for (int i = 0; i < selected.Count; i++)
        {
            for (int j = 0; j < Skills.Count; j++)
                if (Skills[j].Equals(selected[i]))
                {
                    Skills[j].time = Time.deltaTime;
                }
        }
        exist = false;

        ClassCombination comb = new ClassCombination(selected, Time.deltaTime);

        if (newcontrol.skillCombinations.Count != 0)
        {
            for (int k = 0; k < newcontrol.skillCombinations.Count; k++)
            {
                if (newcontrol.skillCombinations[k].combination.Equals(selected))
                {
                    exist = true;
                    newcontrol.skillCombinations[k].time.Add(Time.deltaTime);
                    newcontrol.skillCombinations[k].veces++;
                }

            }
        }
    }
    */


    void Start()
    {
        rend = GetComponent<Renderer>();
        rend.enabled = true;

        proceduralController = GameObject.FindGameObjectWithTag("Controller");
        newcontrol = proceduralController.GetComponent<Controller>();

        for (int i = 0; i < newcontrol.Skills.Count; i++)
        {
            list.Add(newcontrol.Skills[i]);
        }

       Procedural();

        if (notallMaterial)
        {
            if (proceduralColor)
                ProceduralColor();
            if (proceduralTexture)
                ProceduralTexture();
            if (proceduralShader)
                ProceduralShader();
        }
        else
            ProceduralAllMaterial();

    }

    // Update is called once per frame
    void Update()
    {
        



        timer += Time.deltaTime;

        if (death && !newcontrol.withTime)
        {
            for (int i = 0; i < selected.Count; i++)
            {
                for (int j = 0; j < newcontrol.Skills.Count; j++)
                    if (newcontrol.Skills[j].Equals(selected[i]))
                    {
                        newcontrol.Skills[j].deathcount += 1;
                        newcontrol.Skills[j].calcul(difficult);
                    }

            }



            newcontrol.AddLearning(newcontrol.Skills);

            Destroy(this.gameObject);

        }



        if (death && newcontrol.withTime)
        {
            for (int i = 0; i < selected.Count; i++)
            {
                for (int j = 0; j < newcontrol.Skills.Count; j++)
                    if (newcontrol.Skills[j].Equals(selected[i]))
                    {
                        newcontrol.Skills[j].deathcount += 1;
                        newcontrol.Skills[j].times.Add(timer);
                        newcontrol.Skills[j].lastTime = timer;

                        if (newcontrol.average)
                            newcontrol.Skills[j].actualValue = newcontrol.Skills[j].Average();
                        else if (newcontrol.median)
                            newcontrol.Skills[j].actualValue = newcontrol.Skills[j].Median();
                        else if (newcontrol.ajustedaverage)
                            newcontrol.Skills[j].actualValue = newcontrol.Skills[j].Average() / newcontrol.Skills[j].deathcount;
                        else if (newcontrol.ajustedmedian)
                            newcontrol.Skills[j].actualValue = newcontrol.Skills[j].Median() / newcontrol.Skills[j].deathcount;                       
                        else if (newcontrol.lastTime)
                            newcontrol.Skills[j].actualValue = newcontrol.Skills[j].lastTime;

                    }

            }

            if (newcontrol.average)
            {
                newcontrol.AddAverage(newcontrol.Skills);
            }
            else if (newcontrol.median)
            {
                newcontrol.AddMedian(newcontrol.Skills);
            }
            else if (newcontrol.ajustedmedian)
            {
                newcontrol.AddAjustedMedian(newcontrol.Skills);
            }
            else if (newcontrol.ajustedaverage)
            {
                newcontrol.AddAjustedAverage(newcontrol.Skills);
            }
            else if (newcontrol.lastTime)
            {
                newcontrol.AddlastTime(newcontrol.Skills);
            }

            Destroy(this.gameObject);
        }

    }



}


[CustomEditor(typeof(CharacterGeneration))]
public class MyScriptEditor : Editor
{
    private CharacterGeneration sa;
    override public void OnInspectorGUI()
    {

 
        var myScript = target as CharacterGeneration;
        base.OnInspectorGUI();

        myScript.notallMaterial = EditorGUILayout.Toggle("Not All Material", myScript.notallMaterial);
        
        using (var group = new EditorGUILayout.FadeGroupScope(Convert.ToSingle(myScript.notallMaterial)))
        {
            
            if (group.visible == true)
            {

                EditorGUI.indentLevel++;
                
                myScript.proceduralColor = EditorGUILayout.Toggle("Procedural Color", myScript.proceduralColor);
                myScript.proceduralTexture = EditorGUILayout.Toggle("Procedural Texture", myScript.proceduralTexture);
                myScript.proceduralShader = EditorGUILayout.Toggle("Procedural Shader", myScript.proceduralShader);

                EditorGUI.indentLevel--;
            }
        }
        Undo.RecordObject(myScript, "Not All Material");
        Undo.RecordObject(myScript, "Procedural Color");
        Undo.RecordObject(myScript, "Procedural Texture");
        Undo.RecordObject(myScript, "Procedural Shader");

    }
}



