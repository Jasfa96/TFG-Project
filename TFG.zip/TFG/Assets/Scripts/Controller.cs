﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;

public class Controller : MonoBehaviour
{
    /*
    public bool mov;
    float speed = 4.0f;
    float gravity = 8.0f;
    float rot = 0.0f;
    float rotSpeed = 200.0f;
    */
    //Vector3 moveDir = Vector3.zero;
    //Vector3 skilldirection = new Vector3(0, 0, 1);
    //CharacterController controller;
    //Animator anim;
    //GameObject[] effect;
    //Renderer rend;
    [HideInInspector]
    public bool withTime;
    [HideInInspector]
    public bool average;
    [HideInInspector]
    public bool median;
    [HideInInspector]
    public bool ajustedmedian;
    [HideInInspector]
    public bool ajustedaverage;
    [HideInInspector]
    public bool lastTime;


    [System.NonSerialized]
    public float LearnedValue; 
    public List<ClassSkill> Skills;


    private void option()
    {

                if (((average ? 1 : 0) + (median ? 1 : 0) + (lastTime ? 1 : 0) + (ajustedmedian ? 1 : 0) + (ajustedaverage ? 1 : 0) > 1) || ((average ? 1 : 0) + (median ? 1 : 0) + (lastTime ? 1 : 0) + (ajustedmedian ? 1 : 0) + (ajustedaverage ? 1 : 0) == 0))
                {
                    Debug.Log("You must select one option");
                    Application.Quit();
                }

    }


    public void AddAverage(List<ClassSkill> sk) 
    {
        LearnedValue = 0;
        
        for (int i = 0; i < sk.Count; i++)
        {
            if (sk[i].deathcount > 0)
            {
                LearnedValue += sk[i].Average();
                
            }
            else
            {
                LearnedValue += sk[i].actualValue;
            }
        }


    }

    public void AddAjustedAverage(List<ClassSkill> sk)
    {
        LearnedValue = 0;

        for (int i = 0; i < sk.Count; i++)
        {
            if (sk[i].deathcount > 0)
            {
                if (sk[i].Average() / sk[i].deathcount > 0)
                    LearnedValue += sk[i].AjustedAverage();
                else
                    LearnedValue += sk[i].minValue;

            }
            else
            {
                LearnedValue += sk[i].actualValue;
            }
            Debug.Log(LearnedValue);
        }
    }

    public void AddMedian(List<ClassSkill> sk)
    {
        LearnedValue = 0;
        
        for (int i = 0; i < sk.Count; i++)
        {
            if (sk[i].deathcount > 0)
            {
                LearnedValue += sk[i].Median();

            }
            else
            {
            LearnedValue += sk[i].actualValue;
            }
        }
    }

    public void AddAjustedMedian(List<ClassSkill> sk)
    {
        LearnedValue = 0;

        for (int i = 0; i < sk.Count; i++)
        {
            if (sk[i].deathcount > 0)
            {
                LearnedValue += sk[i].AjustedMedian();

            }
            else
            {
                LearnedValue += sk[i].actualValue;
            }
        }

    }

    public void AddlastTime(List<ClassSkill> sk)
    {
        LearnedValue = 0;
        for (int i = 0; i < sk.Count; i++)
        {
            if (sk[i].deathcount > 0)
            {
                LearnedValue += sk[i].lastTime;

            }
            else
            {
                LearnedValue += sk[i].actualValue;
            }
        }
    }

    public void AddLearning(List<ClassSkill> sk)
    {
        LearnedValue = 0;
        for (int i = 0; i < sk.Count; i++)
        {
            LearnedValue += sk[i].actualValue;
        }
    }

    // Start is called before the first frame update
    void Start()
    {

        if (withTime)
        {
            option();
            if (average)
                AddAverage(Skills);
            else if (median)
                AddMedian(Skills);
            else if (ajustedaverage)
                AddAjustedAverage(Skills);
            else if (ajustedmedian)
                AddAjustedMedian(Skills);
            else if (lastTime)
                AddlastTime(Skills);
        }
        else
        {
        AddLearning(Skills);
        }

    }

}


[CustomEditor(typeof(Controller))]
public class MyControllerScriptEditor : Editor
{
    override public void OnInspectorGUI()
    {
        var myScript = target as Controller;
        base.OnInspectorGUI();

        myScript.withTime = EditorGUILayout.Toggle("Using Time", myScript.withTime);
        
        using (var group = new EditorGUILayout.FadeGroupScope(Convert.ToSingle(myScript.withTime)))
        {
            if (group.visible == true)
            {
                EditorGUI.indentLevel++;

                myScript.average = EditorGUILayout.Toggle("Average", myScript.average);
                myScript.median = EditorGUILayout.Toggle("Median", myScript.median);
                myScript.ajustedaverage = EditorGUILayout.Toggle("Ajusted Average", myScript.ajustedaverage);
                myScript.ajustedmedian = EditorGUILayout.Toggle("Ajusted Median", myScript.ajustedmedian);
                myScript.lastTime = EditorGUILayout.Toggle("Last time", myScript.lastTime);
                EditorGUI.indentLevel--;
            }

            Undo.RecordObject(myScript, "Using Time");
            Undo.RecordObject(myScript, "Average");
            Undo.RecordObject(myScript, "Median");
            Undo.RecordObject(myScript, "Ajusted Average");
            Undo.RecordObject(myScript, "Ajusted Median");
            Undo.RecordObject(myScript, "Last time");
        }
        
    }

}