﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ClassSkill : System.Object
{
    public GameObject skill; //Prefab de la habilidad
    public int type; //Tipo de habilidad
    public List<int> counter; // Efecto contrario
    public List<int> exclusive = new List<int>(); // Determina en que parte puede aparecer el objeto.
    public List<string> tag = new List<string>(); //tag del personaje seleccionado
    public int effect; // el transform que le añadimos
    public int strenght; // Fuerza de la habilidad
    public float lastTime; // Tiempo que ha tardado el usuario en derrotar al enemigo con dicha habilidad

    [HideInInspector]
    public List<float> times;


    public float maxValue;
    public float actualValue;
    public float minValue;
    public float reduction;


    public int deathcount;

    public ClassSkill()
    {

    }

    public void calcul(float diff)
    {
        if (actualValue - reduction >= minValue)
        {
            actualValue = maxValue - (reduction * deathcount * diff);
        }
        else
            actualValue = minValue;
    }

    public float Average()
    {
        float average = 0;
        for (int i = 0; i < times.Count; i++)
        {
            average += times[i];

        }
        if (average > 0)
        {
            average = average / times.Count;
            actualValue = average;
            if (average <1)
                actualValue = minValue;
            else
                actualValue = average / deathcount;

        }
        return actualValue;
    }

        public float AjustedAverage()
    {
        float average = 0;
        for (int i = 0; i < times.Count; i++)
        {
            average += times[i];

        }
        if (average > 0)
        {
            average = (average / times.Count) / deathcount;

            if (average < 1)
                actualValue = minValue;
            else
                actualValue = average / deathcount;

        }
        return actualValue;

    }

    public float Median()
    {
        int position = 0;
        float median = 0;
        if (times.Count > 0)
        {
            times.Sort();
            if ((times.Count % 2) == 0)
            {
                position = times.Count / 2;
                median = (times[position] + times[position - 1]) / 2;
            }
            else
            {
                position = times.Count / 2;
                median = times[position];
            }
            if (median < 1)
                actualValue = minValue;
            else
                actualValue = median;

        }

            return actualValue;       

    }


    public float AjustedMedian()
    {
        int position = 0;
        float median = 0;
        if (times.Count > 0)
        {
            times.Sort();
            if ((times.Count % 2) == 0)
            {
                position = times.Count / 2;
                median = (times[position] + times[position - 1]) / 2;
            }
            else
            {
                position = times.Count / 2;
                median = times[position];
            }
            if (median / deathcount <1)
                actualValue = minValue;
            else
                actualValue = median/deathcount;

        }

            return actualValue;

    }
}

