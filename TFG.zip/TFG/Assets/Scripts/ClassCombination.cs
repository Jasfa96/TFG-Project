﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ClassCombination : System.Object
{
    public List<ClassSkill> combination;
    public List<float> time = new List<float>();
    public int veces;


    public ClassCombination(List<ClassSkill> comb, float tim)
    {
        combination = comb;
        time.Add(tim);
        veces = 1;
    }

    public float Average()
    {
        float average = 0;
        for (int i = 0; i < time.Count; i++)
        {
            average += time[i];
        }
        average = average / time.Count;
        return average;
    }   

    public float Median()
    {
        int position=0;
        float median = 0;
        if (time.Count > 0)
        {

            time.Sort();
            if ((time.Count % 2) == 0)
            {
                position = time.Count / 2;
                median = (time[position] + time[position + 1]) / 2;
            }
            else
            {
                position = time.Count / 2;
                median = time[position];
            }
        }
        return median;
            
    }
        
}


