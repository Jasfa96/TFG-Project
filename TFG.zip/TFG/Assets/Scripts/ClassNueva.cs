﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClassNames : MonoBehaviour
{
    public string targetName;
    public List<ClassSkill> skills;

    public ClassNames(string nm, List<ClassSkill>sk)
    {
        targetName = nm;
        skills = sk;
    }

    public void AddName(string nm)
    {
        targetName = nm;
        skills = new List<ClassSkill>();
    }

}
