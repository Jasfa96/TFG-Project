﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour
{
    [SerializeField] private Transform Enemy;
    [SerializeField] private Transform respawnPoint;
    float timer = 10;
    public float lifetime;
    void Start()
    {
        
        Instantiate(Enemy, respawnPoint.position, respawnPoint.rotation);
        Enemy.tag = "Enemy";
        lifetime = 0;
    }

    void Update()
    {
        
        lifetime += Time.deltaTime;
        if (GameObject.FindGameObjectsWithTag("Enemy").Length == 0)
        {
            
            timer = timer - Time.deltaTime;
            if (timer <= 0)
            {

                Instantiate(Enemy, respawnPoint.position, respawnPoint.rotation);
                Enemy.tag = "Enemy";
                timer = 10;               
            }
            lifetime = 0;
        }

        
    }
}
